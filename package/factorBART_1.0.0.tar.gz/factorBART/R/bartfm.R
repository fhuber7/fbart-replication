#' Factor-augmented BART VAR (baseline sampler)
#'
#' Gibbs sampler for the model
#' \deqn{y_t = A x_t + \Lambda_\mu \mu(x_t) + \Lambda_q q_t + \varepsilon_t,}
#' where \eqn{x_t = (y_{t-1}', \dots, y_{t-p}', 1)'} stacks the VAR lags,
#' \eqn{\mu : \mathbb{R}^K \to \mathbb{R}^{Q_\mu}} is the latent BART factor
#' map, \eqn{\Lambda_\mu} is its M-by-Q_\mu loading matrix, \eqn{q_t \sim N(0,I)}
#' are Q_q structural factors with sign-restricted loadings, and
#' \eqn{\varepsilon_t \sim N(0,\, \mathrm{diag}(H))}.
#'
#' The default prior on \eqn{A} is Horseshoe with own-lag mean 0.6; loadings
#' \eqn{\Lambda_\mu} use a row-wise Horseshoe with multiplicative column
#' shrinkage; \eqn{H} uses an inverse-gamma prior; \eqn{\Lambda_q} is drawn
#' from a truncated normal under sign restrictions. The nonlinear factor map
#' \eqn{\mu} is sampled with \pkg{dbarts}.
#'
#' Identification of \eqn{(A, \Lambda_\mu, \mu)} is **not** enforced during
#' sampling; the user should call \code{\link{identify_factors}} on the
#' returned draws to apply the ex-post posterior projection
#' (Chakraborty, Walsh, Strigari, Mallick & Bhattacharya, 2026, Technometrics).
#'
#' @param Yraw    T x M matrix of (standardized) responses with column names.
#' @param nsave   number of post-burn-in MCMC iterations to retain.
#' @param nburn   number of burn-in MCMC iterations.
#' @param nout    number of thinned draws to store.
#' @param prior   prior on A: "HS" (Horseshoe, default) or "Minnesota".
#' @param p       number of VAR lags.
#' @param Q.mu    number of nonlinear BART factors.
#' @param Q.q     number of sign-identified structural factors.
#' @param sign    enforce sign restrictions on Lambda_q (default TRUE if
#'                \code{sign.mat} provided).
#' @param sign.mat  M x Q.q x 2 sign-restriction array (lb/ub per column).
#' @param nhor    forecast / IRF horizon (default 24).
#' @param sl.shock integer vector of structural shocks to compute IRFs for.
#' @param size.grid vector of shock sizes (in s.d. units).
#' @param Y.sd, Y.m  per-equation s.d. and mean used to back out raw scale.
#' @param VAR     if FALSE, drops the A x_t block (default TRUE).
#' @param trans.1, trans.2  variable indices to cumulate once / twice in IRFs.
#' @param FM      if FALSE, switches off the BART block.
#' @param IRF     if TRUE, compute GIRFs at each thinned draw.
#' @param scens   if TRUE, compute partial-dependence-style factor scenarios.
#' @param set.T   integer vector of valid start dates for IRF anchoring.
#' @param shrink.load  "rowwise" (default) or "global" Horseshoe for Lambda_mu.
#' @param ident   identification used during sampling: "unident" (default for
#'   ex-post projection), "identity" (Lambda_mu[1:Q.mu, 1:Q.mu] = I), or
#'   "lower.tri" (lower-triangular with unit diagonal).
#' @param column.shrink  if TRUE, multiplicative gamma-process column shrinkage
#'   on Lambda_mu (default TRUE).
#'
#' @return A list with components
#'   \item{A.store}{nout x K x M draws of A}
#'   \item{Lambdamu}{nout x M x Q.mu loading draws}
#'   \item{Lambdaq}{nout x M x Q.q draws}
#'   \item{mu}{nout x T x Q.mu factor draws}
#'   \item{q}{nout x T x Q.q draws}
#'   \item{IRF}{nout x M x nhor x |size.grid| x |sl.shock| (if IRF=TRUE)}
#'   \item{pred}{nout x M x nhor predictive draws}
#'   \item{var.expl}{nout x M variance share due to the nonlinear factor block}
#'   \item{factor.fit.store, scenarios, var.scenarios, pi, tau, psi}{aux storage}
#'
#' @references
#' Chakraborty, A., Walsh, J. L., Strigari, L., Mallick, B. K., & Bhattacharya, A.
#' (2026). Orthogonal Calibration via Posterior Projections with Applications to
#' the Schwarzschild Model. \emph{Technometrics}, 68(1), 14-23.
#'
#' @seealso \code{\link{identify_factors}}, \code{\link{compute_GIRF}}
#' @export
bartfm <- function(Yraw, nsave, nburn, nout, prior="HS", p, Q.mu=3, Q.q=2, sign=TRUE, sign.mat=NULL, nhor=24, sl.shock=1, size.grid = c(-3, -2, -1, 1, 2, 3), Y.sd=NULL, Y.m=NULL, VAR=TRUE, trans.1=NULL, trans.2=NULL, FM=TRUE, IRF=FALSE, scens=TRUE, set.T=NULL, shrink.load="rowwise", ident="identity", column.shrink = TRUE, n.paths=50, align.signs.init=FALSE,
                   dates_pdp = NULL, focal_pdp = "EBP"){
  ## dates_pdp:  optional integer vector of time indices (rows of X
  ##             after lag-embedding) at which to compute time-varying
  ##             scenarios for the focal predictor focal_pdp.  At each
  ##             saved MCMC draw and each t in dates_pdp, the function
  ##             evaluates the conditional-mean PDP of every output m
  ##             when X[t, focal_lag_cols] varies along sl.quants and
  ##             ALL OTHER lag columns are pinned at X[t, .] (i.e. the
  ##             actual history at quarter t, not the unconditional
  ##             median).  Default NULL preserves the original
  ##             behaviour.  Output:  var.scenarios.dates (nout x
  ##             length(dates_pdp) x length(sl.quants) x M, raw units).
  
 #  Yraw = Yraw; nsave = nsave; nburn = nburn; p = p; Q.mu = 4; nout=500;
 #  Q.q = ncol(sign.mat); sign = TRUE; trans.1 = sums.1; trans.2 = sums.2;
 #  set.T = NULL; sign.mat = sign.mat; nhor = nhor; sl.shock = sl.shock;
 #  size.grid = size.grid.static; Y.sd = Y.sd; Y.m = Y.mean; VAR = TRUE; IRF = TRUE; prior <- "HS";shrink.load <- "rowwise"
 #  FM <- TRUE
 #  scens <- TRUE
 #  column.shrink <- TRUE
 # 
 # ident <- "unident" # lower.tri for a lower triangular identification scheme; identity for setting the upper Q.mu, Q.mu matrix to I
  require(dbarts)
  require(stochvol)
  
  if (is.null(sign.mat)) sign <- FALSE
  
  if (sign){
    #sign.mat <- sign.mat[colnames(Yraw),,] # Array of sign restrictions. First dimension gives you the variable to restrict; second dimension gives you the lower bound and third the upper bound
    signs <- sign.mat
    Q.q <- ncol(signs) # Number of structural factors. 
  }
  
  bart.prior <- list("level"=0.95, "exp"=2, "mu.sd"=2, "trees"=250) # Setup for BART
  
  ntot <- nsave+nburn
  
  # Set up data matrices
  M <- ncol(Yraw) # Columns of the response matrix / Number of equations in the system
  if (is.null(Y.sd)) Y.sd <- rep(1, M) # If series enter the function in non-standardized form
  if (is.null(Y.m))  Y.m  <- rep(0, M) # back-out shift; defaults to 0 (i.e. centred data)
  
  Y <- embed(Yraw, p+1) # Creates matrices to set up the VAR
  
  X <- cbind(Y[, (M+1):ncol(Y)],1) # These are the lags of y(t) and a constant
  Y <- Y[, 1:M] # Contemporenous values of y(t)
  
  T <- nrow(Y) # Number of observations left after creating p lags
  K <- ncol(X) # Number of covariates in X
  k <- K*M # total number of coefficients in the VAR part
  
  # Prior setup 
  V.a <- matrix(1, K, M) # Starting value for the VAR prior
  
  prior.a <- matrix(0, K, M)
  prior.a[1:M, 1:M] <- diag(M)*0.6 # persistence on the first own lag of a series. Need to put that into the function argument
  
  # Define starting values by simply using the prior mean
  Sigma_q <- diag(Q.q) * 1

  # Set up priors on the VARs (either horseshoe or Minnesota)
  if (prior=="HS"){
    # We use a Horseshoe shrinkage prior on the VAR coefficients. 
    # The Horseshoe doesn't have any hyperparameters to tune but we need some starting values
    
    lambda.var <- rep(0.1, k)
    nu.var <- rep(0.1, k)
    tau.var <- 0.1
    zeta.var <- 0.1
  }else{
    sigma.sd <- matrix(NA, M, 1)
    for (j in 1:M){
      y.j <- Y[, j]
      X.j <- embed(y.j, p+1)
      Y.j <- X.j[, 1]
      X.j <- X.j[, 2:ncol(X.j)]
      lm.j <- lm(Y.j~X.j)
      sigma.sd[j, 1] <- sqrt(sum(lm.j$residuals^2)/lm.j$df.residual)
    }
    
    scale_1 <- scale_2 <- scale_3 <- 0.1
    a_bar_1 <- 0.04
    a_bar_2 <- 0.0016
    a_bar_3 <- 10
    
    ind <- matrix(0, M , p )
    for (i in 1:M){
      ind[i,] <- seq(i, M*p, by=M)
    }
    
    V.a <- get_V(a_bar_1=a_bar_1,a_bar_2=a_bar_2, a_bar_3=a_bar_3 , ind1=ind,sigma_sq1=sigma.sd^2, p1=p,M1=M, K1=K)
  }
  
  # Starting values for the prior on Lambda.mu
  pi.Lambda <- rep(1, Q.mu) # Remains at 1 if we do not use column-wise shrinkage as well
  if (column.shrink){
    kappa <- 2
    a_pi  <- 3
    b_pi <- 0.03
    
    pi <- 1
    pi.Lambda <- pi / (1:Q.mu)^kappa
  }
  
  if (shrink.load == "rowwise"){
    lambda.Lambda <- matrix(0.1, Q.mu, M)
    nu.Lambda <- matrix(0.1, Q.mu, M)
    tau.Lambda <- matrix(0.1, M)
    zeta.Lambda <- matrix(0.1, M)
  }else{
    lambda.Lambda <- rep(0.1, M*Q.mu)
    nu.Lambda <- rep(0.1, M*Q.mu)
    tau.Lambda <- 0.1
    zeta.Lambda <- 0.1
  }
  
  if (FM){
    psi.Lambda <- matrix(1, M, Q.mu)
  }else{
    psi.Lambda <- matrix(1e-14, M, Q.mu) # If we drop the nonlinear factor term we simply shrink excessively Lambda to zero
  }
  
  psi.Lambda.tilde <- psi.Lambda
  # Next, we define a prior on H, the error variances in the measurement equation. Could do SV here. But let's keep it simple for now
  # Prior is sigma_hi^2 ~ iG(a_h, b_h)
  a_h <- 0.01
  b_h  <- 0.01
  
  # Starting values for H
  H <- matrix(b_h/a_h, T, M) # We do it in this form to make adding SV simpler later on (in case we'd like to have it)
  
  # Now set up BART for mu_f and mu_q
  # Before doing so, construct starting values for f and q
  # First, get starting values for A.draw
  if (VAR){
    A.draw <- solve(crossprod(X)) %*% crossprod(X, Y)
  }else{
    A.draw <- matrix(0, K, M)
  }
  
  Y.A <- Y - X %*% A.draw # Residuals. Notice that Y.A implies Y conditioned on A
  
  pca.f <- princomp(Y.A) # Runs PCA to obtain the first set of factors
  f.draw <- pca.f$scores[, 1:Q.mu, drop=FALSE]  # This is just a rough starting value. We don't use it later on.
  
  # Get starting values for mu(x(t))
  mu <- matrix(0, T, Q.mu)

  # These three parameters are the regularization hyperparms for BART
  cgm.level <- bart.prior$level
  cgm.exp <- bart.prior$exp
  sd.mu <- bart.prior$mu.sd
  num.trees <- bart.prior$trees
  
  #This object contains all parameters we need for the sampler for the two BART models our model builds on
  control.bart <- dbartsControl(verbose = FALSE, keepTrainingFits = TRUE, useQuantiles = FALSE,
                                keepTrees = FALSE, n.samples = ntot,
                                n.cuts = 100L, n.burn = nburn, n.trees = num.trees, n.chains = 1,
                                n.threads = 1, n.thin = 1L, printEvery = 1,
                                printCutoffs = 0L, rngKind = "default", rngNormalKind = "default",
                                updateState = FALSE)
  
  prior.sig = c(10000^50, 0.5) # This fixes the variances to be equal to 1
  sigma.init <- 1
  sampler.mu <- list()
  for (j in 1:Q.mu){
    sampler.mu[[j]] <- dbarts(f.draw[,j]~ cbind(X, 1:T), control = control.bart,tree.prior = cgm(cgm.exp, cgm.level), 
                              node.prior = normal(sd.mu), n.samples = nsave, weights=rep(1,T), sigma=sigma.init, 
                              resid.prior = chisq(prior.sig[[1]], prior.sig[[2]]))
    init.mu.draw <- sampler.mu[[j]]$run(0L, 1L)
    
    mu[, j] <-  init.mu.draw$train
  }
  
  if (!FM) mu <- mu*0
  
  # Get an estimate of the factor loadings Lambda.mu
  Lambda.mu <- matrix(0, M, Q.mu)
  if (FM){
    for (j in 1:M){
      Lambda.mu[j, ] <- solve(crossprod(mu)+diag(Q.mu)) %*% crossprod(mu, Y.A[, j])
    }
  }
  
  # Next, set up starting values for mu.q
  # Before doing so, need to get a starting value for q
  Y.A.mu <- Y - X%*%A.draw - mu %*% t(Lambda.mu)
  
  pca.q <- princomp(Y.A.mu) # PCA for obtaining q
  q.draw <- pca.q$scores[, 1:Q.q] # uses the first Q.q PC's
  
  # Get an estimate of the factor loadings Lambda.q
  Lambda.q <- matrix(0, M, Q.q)
  for (j in 1:M){
    Lambda.q[j, ] <- solve(crossprod(q.draw)+diag(Q.q)) %*% crossprod(q.draw, Y.A.mu[, j])
  }

  ## Optional sign-aware initialization.  Under sign restrictions the
  ## truncated-Gaussian Step IV can trap a column of Lambda.q at zero
  ## if PCA happens to pick the opposite sign convention; that in turn
  ## leaks the column's variance into H and biases the other columns.
  ## When align.signs.init=TRUE we flip any factor whose initial loadings
  ## mostly disagree with the prescribed sign pattern.  Because
  ## (q_j, Lambda_{.,j}) and (-q_j, -Lambda_{.,j}) describe the same
  ## observable model, this is a likelihood-preserving transformation
  ## of the starting state.  Default FALSE preserves the legacy MCMC
  ## trajectory for runs that were already producing sensible IRFs.
  if (align.signs.init && sign && !is.null(sign.mat)) {
    for (j in seq_len(Q.q)) {
      lb.j <- sign.mat[, j, "lb"]; ub.j <- sign.mat[, j, "ub"]
      target.sign <- ifelse(is.finite(lb.j) & lb.j >= 0, 1L,
                     ifelse(is.finite(ub.j) & ub.j <= 0, -1L, 0L))
      score <- sum(sign(Lambda.q[, j]) * target.sign, na.rm = TRUE)
      if (score < 0) {
        Lambda.q[, j] <- -Lambda.q[, j]
        q.draw[, j]   <- -q.draw[, j]
      }
    }
  }

  # Set up storage matrices
  A.store <- array(NA, c(nout, K, M))
  factor.fit.store <- array(NA, c(nout, T, M))
  mu.store <- array(NA, c(nout, T, Q.mu))
  q.store <- array(NA, c(nout, T, Q.q))
  psif.store <- Lambdaf.store <- array(NA, c(nout, M, Q.mu))
  tau.global.store <- array(NA, c(nout, M))
  pi.store <- array(NA, c(nout, Q.mu))
  Lambdamu.store <- array(NA, c(nout, M, Q.mu))
  Lambdaq.store <- array(NA, c(nout, M, Q.q))
  IRF.store <- array(NA, c(nout, M, nhor, length(size.grid), length(sl.shock))); dimnames(IRF.store) <- list(NULL, colnames(Yraw), 0:(nhor-1), size.grid, sl.shock)
  pred.store <- array(NA, c(nout, M, nhor)); dimnames(pred.store) <- list(NULL, colnames(Yraw), 1:nhor)
  var.explained <- array(NA, c(nout, M))
  if (scens){
    sl.quants <- seq(0, 1, 0.01)
    scens.store <- array(NA, c(nout, M, length(sl.quants), Q.mu))
    var.scens.store <- array(NA, c(nout, M, length(sl.quants), M))
    dimnames(scens.store) <- list(NULL, colnames(Yraw), sl.quants, 1:Q.mu)
    dimnames(var.scens.store) <- list(NULL, colnames(Yraw), sl.quants, colnames(Yraw))

    x.lab <- c(rep(colnames(Yraw), p), "cons")

    ## ---- optional time-varying scenarios for one focal predictor ----
    if (!is.null(dates_pdp)){
      stopifnot(is.numeric(dates_pdp))
      dates_pdp <- as.integer(dates_pdp)
      stopifnot(focal_pdp %in% colnames(Yraw))
      var.scens.dates.store <- array(NA,
        c(nout, length(dates_pdp), length(sl.quants), M))
      dimnames(var.scens.dates.store) <- list(
        NULL, as.character(dates_pdp), sl.quants, colnames(Yraw))
      cat(sprintf("[bartfm] time-varying scenarios on focal '%s' at %d dates\n",
                  focal_pdp, length(dates_pdp)))
    }
  }
  
  thin.set <- round(seq(nburn+1, ntot, length.out=nout))
  i.count <- 0
  
  for (irep in 1:ntot){
    # Step I: Draw from the posterior of the VAR piece of the model
    Y.q.mu <- Y - mu %*% t(Lambda.mu) - q.draw %*% t(Lambda.q)
    
    if (VAR){
      # Estimate the VAR eq-by-eq 
      for (i in 1:M){
        y.i <- Y.q.mu[, i] / sqrt(H[, i])
        X.i <- X / sqrt(H[, i])
        V.i <- solve(crossprod(X.i) + diag(1/V.a[, i]))
        m.i <- V.i %*% (crossprod(X.i, y.i) + diag(1/V.a[, i])%*%prior.a[,i])
        A.draw[, i] <- m.i + t(chol(V.i))%*%rnorm(K)
      }
    }
    # Step II: Draw the factor loadings Lambda.q
    Y.A.q <- Y - X%*%A.draw - q.draw %*% t(Lambda.q)
    
    if (ident == "identity"){
      i.ident <- Q.mu+1
      Lambda.mu[1:Q.mu, 1:Q.mu] <- diag(Q.mu)
    }else if (ident == "lower.tri"){ # If we use a lower triangular identification scheme the (1,1) element of L is 1
      Lambda.mu[upper.tri(Lambda.mu)] <- 0
      diag(Lambda.mu[1:Q.mu, 1:Q.mu]) <- 1
      i.ident <- 2
    }else{ # for anything else
      i.ident <- 1
    }
    
    for (i in i.ident:M){
      if (ident == "lower.tri"){
        if (i == 1){ 
          next 
        }else if (i <= Q.mu){
          y.i <- Y.A.q[, i]/sqrt(H[, i]) - mu[, i] /sqrt(H[,i])
          X.i <- mu[, 1:(i-1), drop=FALSE] /sqrt(H[,i])
          
          Q.mu.i <- ncol(X.i)
          if (Q.mu.i > 1){
            prior.lambda.inverse <- diag(1/psi.Lambda[i, 1:(i-1)]) 
          } else {
            prior.lambda.inverse <- 1/psi.Lambda[i, 1:(i-1)]
          }
          i.cols <- 1:(i -1)
        } else {
          y.i <- Y.A.q[, i]/sqrt(H[, i]) 
          X.i <- mu /sqrt(H[,i])
          Q.mu.i <- ncol(X.i)
          if (Q.mu.i > 1) prior.lambda.inverse <- diag(1/psi.Lambda[i, ]) else prior.lambda.inverse <- 1/psi.Lambda[i, ]
          i.cols <- 1:Q.mu
        }
      } else {
        y.i <- Y.A.q[, i]/sqrt(H[, i]) 
        X.i <- mu /sqrt(H[,i])
        Q.mu.i <- Q.mu
        if (Q.mu.i > 1) prior.lambda.inverse <- diag(1/(psi.Lambda.tilde[i, ])) else prior.lambda.inverse <- 1/psi.Lambda.tilde[i, ]
        i.cols <- 1:Q.mu
      }
      
      V.i <- try(solve(crossprod(X.i) + prior.lambda.inverse), silent=TRUE) # Standard normal prior on the factor loadings
      if (is(V.i, "try-error")) V.i <- MASS::ginv(crossprod(X.i) + prior.lambda.inverse) 
      m.i <- V.i %*% crossprod(X.i, y.i)
      
      
      cholV <- try(t(chol(V.i)), silent=TRUE)
      if (is(cholV, "try-error")) cholV <- t(chol(V.i, pivot=TRUE))
                   
      Lambda.mu[i, i.cols] <- as.numeric(m.i + cholV%*%rnorm(Q.mu.i))
    }
 
    # Step III: Draw the BART piece (only if FM=TRUE)
    if (FM){
      ord <- 1:Q.mu#sample.int(Q.mu)   # random permutation
      
      for (j in 1:Q.mu){
        resp.j.unscaled <- Y.A.q - mu[, -j]%*%t(Lambda.mu[, -j])
        lambda.j.scale <- (1/sum(Lambda.mu[,j]^2))%*%t(Lambda.mu[,j])
        resp.j.scaled <- resp.j.unscaled %*% t(lambda.j.scale)
        
        
        weights.m <- rep(1/(H[1, ]%*%t(lambda.j.scale^2)), T) # Sets weights
        sampler.mu[[j]]$setWeights(weights.m)
        sampler.mu[[j]]$setResponse(resp.j.scaled) #update the factors accordingly
        
        init.mu.draw <- sampler.mu[[j]]$run(0L, 1L)
        
        mu[, j] <-  init.mu.draw$train
      }
    }
  
    # Step IV: Sample the factor loadings related to q. Notice: these have sign restrictions!
    Y.A.mu <- Y - X%*%A.draw - mu%*%t(Lambda.mu)
    
    if (Q.q > 1) prior.lambda <- diag(Q.q)*1/100 else prior.lambda <- 1/100  #almost flat prior on the loadings (when within the intervals)
    for (mm in 1:M){
      normalizer <- 1/sqrt(H[, mm])
      q.draw.hat <- q.draw * normalizer
      y.mm.hat <- Y.A.mu[ , mm] * normalizer
      L.post <- solve(crossprod(q.draw.hat) + prior.lambda)
      a.post <- L.post %*% crossprod(q.draw.hat, y.mm.hat)
      
      if (sign){
        lambda.q.draw <- try(TruncatedNormal::rtmvnorm(n = 1, mu = a.post, sigma = L.post, ub = sign.mat[mm,,"ub"], lb=sign.mat[mm,,"lb"]), silent=TRUE)
        
        if (is(lambda.q.draw, "try-error")){
          lambda.q.draw <- TruncatedNormal::rtmvnorm(n = 1, mu = a.post, sigma = Matrix::forceSymmetric(L.post), ub = sign.mat[mm,,"ub"], lb=sign.mat[mm,,"lb"])
        }
      }else{
        lambda.q.draw <- a.post + t(chol(L.post)) %*% rnorm(Q.q)
      }
      Lambda.q[mm, ] <- lambda.q.draw
    }
    
    # Step V: Draw the structural factors q_t on a t-by-t basis
    Sigma.q.inv <- diag(1/diag(Sigma_q))
    Qt <- Lambda.q %*% Sigma_q %*% t(Lambda.q) + diag(H[T, ]) # same here
    Qt.inv <- solve(Qt)
    
    for (t in 1:T){
      mu.t <-  Sigma_q%*%t(Lambda.q) %*% Qt.inv %*% Y.A.mu[t, ]
      V.t <- Sigma_q - Sigma_q%*%t(Lambda.q)%*%Qt.inv %*% Lambda.q %*% Sigma_q
      q.draw[t, ] <- mu.t + t(chol(V.t))%*%rnorm(Q.q)
    }

    # Step VII: Draw error variances H
    Y.A.mu.q <- Y - X%*%A.draw - mu%*%t(Lambda.mu) - q.draw %*% t(Lambda.q)
    for (j in 1:M){
      h_a <- T/2 + a_h
      h_b <- sum(Y.A.mu.q[, j]^2)/2 + b_h
      H[, j] <- 1/rgamma(1, h_a, h_b)
    }
    
    # Step VIII: Draw prior variances for the VAR piece of the model
    a.draw <- as.vector(A.draw)
    a.prior <- as.vector(prior.a)
    
    if (prior=="HS"){
      hs.var <- get.hs(a.draw - a.prior,lambda.var,nu.var,tau.var,zeta.var) # Does the Horseshoe
      
      lambda.var <- hs.var$lambda
      nu.var <- hs.var$nu
      tau.var <- hs.var$tau
      zeta.var <- hs.var$zeta
      V.a <- matrix(hs.var$psi, K, M)
      V.a[V.a < 1e-6] <- 1e-6
    }
    
    # Step IX: Draw prior variances for the reduced-form factor loadings of the model. Needs a loop
    if (FM){
      if (shrink.load == "rowwise"){
        for (j in i.ident:M){
          if (ident=="lower.tri"){
            if (j <= Q.mu){
              sl.lambdamu <- 1:(j-1)
            }else{
              sl.lambdamu <- 1:Q.mu
            }
          }else{
            sl.lambdamu <- 1:Q.mu
          }
          lambdamu.j <- Lambda.mu[j, sl.lambdamu]
          
          get.psi.j <- get.hs(lambdamu.j/sqrt(pi.Lambda),lambda.hs = lambda.Lambda[sl.lambdamu, j], nu.hs = nu.Lambda[sl.lambdamu, j], tau.hs = tau.Lambda[j], zeta.hs = zeta.Lambda[j])
          lambda.Lambda[sl.lambdamu, j] <- get.psi.j$lambda
          
          tau.Lambda[j] <- get.psi.j$tau
          nu.Lambda[sl.lambdamu, j] <- get.psi.j$nu
          zeta.Lambda[j] <- get.psi.j$zeta
          psi.Lambda[j, sl.lambdamu] <- get.psi.j$psi
        }
      } else { # We're not using this specification. If we use it adjust Lambda.mu depending on the identification strategy
        get.psi <- get.hs(as.vector(Lambda.mu), lambda.hs=lambda.Lambda, nu.hs=nu.Lambda, tau.hs=tau.Lambda, zeta.hs=zeta.Lambda)
        lambda.Lambda <- get.psi$lambda
        nu.Lambda <- get.psi$nu
        zeta.Lambda <- get.psi$zeta
        tau.Lambda <- get.psi$tau
        psi.Lambda <- matrix(get.psi$psi, M, Q.mu)
      }
      psi.Lambda[psi.Lambda > 10^2] <- 10^2
      psi.Lambda[psi.Lambda < 1e-4] <- 1e-4

      if (column.shrink){

        upd <- update_pi_power(
          Lambda = Lambda.mu,
          psi    = psi.Lambda,
          a_pi  = a_pi,
          b_pi  = b_pi
        )
  
        pi        <- upd$pi
       # pi <- ifelse(pi < 1e-4, 1e-4, pi)
        pi.Lambda <- pi / (1:Q.mu)^kappa
        
      }
      psi.Lambda.tilde <- t(t(psi.Lambda) * pi.Lambda)
      
      psi.Lambda.tilde[psi.Lambda.tilde < 1e-5] <- 1e-5
      psi.Lambda.tilde[psi.Lambda.tilde > 1e+1] <- 1e+1
    }
    
    #print(mean(mu))
    
    # if (irep %% 150==0){
    #   par(mfrow=c(4, round(M/4)), mar=c(2,2,2,2))
    #   for (j in 1:M){
    #     ts.plot(cbind(Y[, j], (X%*%A.draw + mu%*%t(Lambda.mu) + q.draw %*% t(Lambda.q))[,j],
    #             (mu%*%t(Lambda.mu) + q.draw %*% t(Lambda.q))[,j]),col=c(1,2,3))
    #   }
    # }
    if (irep %in% thin.set){
      i.count <- i.count+1
      A.store[i.count, , ] <- A.draw
      
      factor.fit.store[i.count, , ] <- (mu%*%t(Lambda.mu))*t(matrix(rep(Y.sd, T), M, T)) + t(matrix(rep(Y.m, T), M, T))
      mu.store[i.count, , ] <- mu#apply(mu,2,function(x) (x-mean(x))/sd(x)) # Normalized
      q.store[i.count, , ] <- apply(q.draw, 2, function(x) (x-mean(x))/sd(x)) # Normalized
      
      Lambdamu.store[i.count, , ] <- Lambda.mu
      Lambdaq.store[i.count, , ] <- Lambda.q
      tau.global.store[i.count, ] <- as.numeric(tau.Lambda)
      psif.store[i.count, , ] <- psi.Lambda.tilde
      pi.store[i.count, ]  <- pi.Lambda
      
      # Compute predictive distributions
      YT <- Y[T, ]
      XT <- X[T, ]
      HT <- H[T, ]
      
      if (p==1) XT <- c(YT, 1) else XT <- c(YT, XT[1:(M*(p-1))], 1)
      
      for (ihorz in 1:nhor){
        tree.pred <- sapply(sampler.mu, function(sampler) sampler$predict(XT))
        var.pred <- t(A.draw) %*% XT
        
        YT <-  (var.pred + Lambda.mu%*%tree.pred) + 
          Lambda.q%*%rnorm(Q.q) + rnorm(M, 0, sqrt(HT))
        
        YT.orig <- YT * Y.sd + Y.m
        
        if (p == 1){
          XT <- c(YT,1)
        }else{
          XT <- c(YT, XT[1:(M*(p-1))], 1)
        }
        
        pred.store[i.count, , ihorz] <- as.numeric(YT.orig)
      }
      
      # Compute the functional relationship per factor (only if scens=TRUE)
      # We need to set up a grid over possible values of the X's. We do this for each lag and on a variable-by-variable basis
      if (scens) {
        var.names <- colnames(Yraw) # IMPORTANT: Yraw should have variable names

        for (i in var.names){
          x.i.quants <- quantile(Yraw[, i], sl.quants)
          XMM <- t(matrix(rep(apply(X, 2, median), length(x.i.quants)), K, length(x.i.quants)))
          XMM[, which(x.lab==i)] <- (matrix(rep(x.i.quants, p), length(x.i.quants), p))

          Xunc <-  t(matrix(rep(apply(X, 2, median),length(x.i.quants)), K, length(x.i.quants)))#apply(X, 2, mean)
          tree.pred <- sapply(sampler.mu, function(sampler) sampler$predict(XMM))
          tree.unc <- sapply(sampler.mu, function(sampler) sampler$predict(Xunc))

          scens.store[i.count,i,,] <- tree.pred

          #browser()
          var.scens.store[i.count, i,  , ] <- ((XMM%*% (A.draw) + tree.pred %*% t(Lambda.mu)) - (Xunc%*%A.draw + tree.unc%*%t(Lambda.mu)))*t(matrix(rep(Y.sd, length(x.i.quants)), M, length(x.i.quants))) + t(matrix(rep(Y.m, length(x.i.quants)), M, length(x.i.quants)))
        }

        ## ---- time-varying scenarios on the focal predictor ---------
        if (!is.null(dates_pdp)){
          x.foc.quants <- quantile(Yraw[, focal_pdp], sl.quants)
          foc_cols     <- which(x.lab == focal_pdp)
          n.foc.q      <- length(x.foc.quants)
          Ysd.mat      <- t(matrix(rep(Y.sd, n.foc.q), M, n.foc.q))
          Ym.mat       <- t(matrix(rep(Y.m,  n.foc.q), M, n.foc.q))
          for (tidx in seq_along(dates_pdp)){
            t_target <- dates_pdp[tidx]
            if (t_target < 1 || t_target > T) next
            ## XMM_t: vary focal lags; pin every other lag at X[t_target, .]
            base_row <- X[t_target, ]
            XMM_t    <- matrix(base_row, n.foc.q, K, byrow = TRUE)
            for (cc in foc_cols) XMM_t[, cc] <- x.foc.quants
            Xunc_t   <- matrix(base_row, n.foc.q, K, byrow = TRUE)
            tree.pred.t <- sapply(sampler.mu, function(s) s$predict(XMM_t))
            tree.unc.t  <- sapply(sampler.mu, function(s) s$predict(Xunc_t))
            var.scens.dates.store[i.count, tidx, , ] <-
              ((XMM_t  %*% A.draw + tree.pred.t %*% t(Lambda.mu)) -
               (Xunc_t %*% A.draw + tree.unc.t  %*% t(Lambda.mu))) *
              Ysd.mat + Ym.mat
          }
        }
      }
    
      # Computes the variation explained of the nonlinear part per variable
      nominator <- diag(Lambda.mu %*% diag(apply(mu,2,var)) %*% t(Lambda.mu))/apply(Y,2,var)
      denominator <- nominator + diag(Lambda.q %*% t(Lambda.q)) + H[T,]
      var.explained[i.count, ] <- (nominator/denominator)*100
      # Computes the IRFs
      if (is.null(set.T)){ 
        rand <- sample(1:T,1) 
      }else{ 
        rand <- sample(set.T,1)
      }
      if (IRF){
        ## KPP-1996 GIRF.  At each (draw, history) we average over
        ## n.paths simulation paths in which we draw future structural
        ## factors q_{T+h} ~ N(0, I_Qq) and idiosyncratic shocks
        ## eta_{T+h} ~ N(0, diag(omega^2)) for h = 1, ..., nhor.  The
        ## shocked and the baseline path share the *same* future-shock
        ## sequence so the difference IRF = E[y_{T+h}|q_T=q*] - E[y_{T+h}]
        ## is identified by the on-impact shock vector only.  When
        ## n.paths == 1, this collapses to the original deterministic
        ## forward iteration with future shocks set to zero -- which is
        ## the limiting case of the KPP construction.
        ##
        ## Implementation note: at each horizon the baseline and shocked
        ## state vectors for *all* paths are stacked into one matrix and
        ## passed to sampler$predict() in a single batched call per BART
        ## factor.  This collapses 2*n.paths predict() dispatches per
        ## horizon down to one, while keeping the per-path arithmetic
        ## and the RNG sequence bit-identical to the loop-by-path
        ## reference implementation.
        for (s.slct in sl.shock){
          for (s.size in 1:length(size.grid)){
            YM <- Y[rand, ]
            XM <- X[rand, ]
            if (p==1) XT <- c(YM,1) else XT <- c(YM, XM[1:(M*(p-1))], 1)
            irf.path.sum <- matrix(0, M, nhor)

            ## Pre-draw the future-shock sequence per path; we draw in
            ## the same per-path order (Q.q*nhor, then M*nhor) as the
            ## legacy loop so the RNG stream is preserved exactly.
            q.future.all   <- array(NA_real_, c(Q.q, nhor, n.paths))
            eta.future.all <- array(NA_real_, c(M,   nhor, n.paths))
            for (i.path in seq_len(n.paths)) {
              q.future.all[, , i.path]   <- matrix(rnorm(Q.q * nhor), Q.q, nhor)
              eta.future.all[, , i.path] <- matrix(rnorm(M * nhor), M, nhor) * sqrt(H[T, ])
            }

            ## Per-path lag-state matrices, all rows initialised to XT.
            XT0.all <- matrix(XT, n.paths, length(XT), byrow = TRUE)
            XT1.all <- matrix(XT, n.paths, length(XT), byrow = TRUE)

            for (ihorz in 1:nhor){
              ## Single batched BART call per factor: stack baseline
              ## and shocked rows for every path into one (2*n.paths)xK
              ## matrix.  sapply binds the resulting per-sampler columns
              ## into a (2*n.paths) x Q.mu matrix.
              XB <- rbind(XT0.all, XT1.all)
              tree.pred <- sapply(sampler.mu,
                                  function(sampler) sampler$predict(XB))
              if (is.null(dim(tree.pred)))
                tree.pred <- matrix(tree.pred, 2 * n.paths, Q.mu)

              tree0.pred.all <- tree.pred[1:n.paths, , drop = FALSE]
              tree1.pred.all <- tree.pred[(n.paths + 1):(2 * n.paths), , drop = FALSE]

              ## Batched linear + tree contributions (n.paths x M).
              var0.pred.all <- XT0.all %*% A.draw
              var1.pred.all <- XT1.all %*% A.draw
              treeL0.all    <- tree0.pred.all %*% t(Lambda.mu)
              treeL1.all    <- tree1.pred.all %*% t(Lambda.mu)

              for (i.path in seq_len(n.paths)) {
                if (n.paths == 1) {
                  shock0 <- matrix(0, Q.q, 1)
                  shock1 <- matrix(0, Q.q, 1)
                  eta.h  <- matrix(0, M, 1)
                } else {
                  shock0 <- matrix(q.future.all[, ihorz, i.path], Q.q, 1)
                  shock1 <- shock0
                  eta.h  <- matrix(eta.future.all[, ihorz, i.path], M, 1)
                }
                if (ihorz == 1){
                  ## condition on coordinate s.slct: 0 for baseline,
                  ## size.grid[s.size] for shocked.
                  shock0[s.slct] <- 0
                  shock1[s.slct] <- size.grid[s.size]
                }

                var0.pred <- matrix(var0.pred.all[i.path, ], M, 1)
                var1.pred <- matrix(var1.pred.all[i.path, ], M, 1)
                treeL0    <- matrix(treeL0.all[i.path, ],    M, 1)
                treeL1    <- matrix(treeL1.all[i.path, ],    M, 1)

                YTp0 <- (var0.pred + treeL0
                         + Lambda.q %*% shock0 + eta.h)
                YTp1 <- (var1.pred + treeL1
                         + Lambda.q %*% shock1 + eta.h)

                irf.path.sum[, ihorz] <- irf.path.sum[, ihorz] +
                  as.numeric((YTp1 - YTp0) * Y.sd)

                if (p == 1){
                  XT0.all[i.path, ] <- c(YTp0, 1)
                  XT1.all[i.path, ] <- c(YTp1, 1)
                } else {
                  XT0.all[i.path, ] <- c(YTp0, XT0.all[i.path, 1:(M*(p-1))], 1)
                  XT1.all[i.path, ] <- c(YTp1, XT1.all[i.path, 1:(M*(p-1))], 1)
                }
              }
            }
            irf.path.mean <- irf.path.sum / n.paths
            IRF.store[i.count, , , s.size, s.slct] <- irf.path.mean

            if (!is.null(trans.1) && length(trans.1) > 0)
              IRF.store[i.count, trans.1, , s.size, s.slct] <-
                t(apply(IRF.store[i.count, trans.1, , s.size, s.slct], 1, cumsum))
            if (!is.null(trans.2) && length(trans.2) > 0)
              IRF.store[i.count, trans.2, , s.size, s.slct] <-
                apply(t(apply(IRF.store[i.count, trans.2, , s.size, s.slct], 1, cumsum)), 1, cumsum)
          }
        }
      }
    }
    if (getOption("factorBART.verbose", FALSE)) print(irep)
  }


  ret.list <- list("IRF"=IRF.store, "pred"=pred.store, "A.store"=A.store, "mu"=mu.store,  "factor.fit.store"=factor.fit.store,
                   "q"=q.store, "Lambdamu"=Lambdamu.store, "Lambdaq"=Lambdaq.store, "pi"=pi.store, "var.expl"=var.explained,
                   "tau"=tau.global.store, "psi"=psif.store,
                   "scenarios"     = if (scens) scens.store     else NULL,
                   "var.scenarios" = if (scens) var.scens.store else NULL,
                   "var.scenarios.dates" = if (scens && !is.null(dates_pdp)) var.scens.dates.store else NULL,
                   "dates_pdp"           = if (scens && !is.null(dates_pdp)) dates_pdp else NULL,
                   "focal_pdp"           = if (scens && !is.null(dates_pdp)) focal_pdp else NULL,
                   ## --- inputs / data carriers needed for ex-post identification ---
                   "X"=X, "Y"=Y, "p"=p, "M"=M, "K"=K, "T"=T, "Q.mu"=Q.mu, "Q.q"=Q.q,
                   "Y.sd"=Y.sd, "Y.m"=Y.m, "var.names"=colnames(Yraw),
                   "ident"=ident)
  class(ret.list) <- c("bartfm", "list")
  return(ret.list)
}
