#' Factor-augmented BART VAR with stochastic volatility (trading-oriented)
#'
#' Gibbs sampler for the model
#' \deqn{y_t = A x_t + \Lambda_\mu \mu(x_t) + \Lambda_q q_t + \varepsilon_t,}
#' with \eqn{\varepsilon_{i,t} \sim N(0, e^{h_{i,t}})} and an idiosyncratic
#' AR(1) stochastic-volatility process on each \eqn{h_{i,t}}, fit through
#' \pkg{stochvol}'s \code{svsample_fast_cpp}. Optionally the q-factor
#' innovations carry their own SV process.
#'
#' This is the trading-focused sibling of \code{\link{bartfm}}. It strips out
#' the IRF/scenario machinery (use \code{bartfm} for those), keeps the
#' predictive-density block, and produces draws from the joint h-step-ahead
#' density of \eqn{y_{T+1}, \dots, y_{T+nhor}} that propagate the SV state
#' forward. Designed for joint modelling of stock returns together with
#' high-frequency factors (FF, VIX, spreads, oil) — all entered as columns of
#' \code{Yraw}.
#'
#' @param Yraw    T x M matrix of (standardized) responses with column names.
#' @param nsave,nburn,nout MCMC budget; \code{nout <= nsave} are the thinned
#'   stored draws.
#' @param p       VAR lag length (1 or 2 for daily).
#' @param Q.mu    number of nonlinear BART factors (0 to switch off).
#' @param Q.q     number of sign-identified structural factors (0 to switch
#'   off — typical for pure forecasting).
#' @param sign.mat optional M x Q.q x 2 sign-restriction array.
#' @param SV.h    if TRUE, idiosyncratic SV on H (default).
#' @param SV.q    if TRUE, AR(1) SV on q-factor innovations (default FALSE).
#' @param sv_priors_h,sv_priors_q optional \pkg{stochvol} prior specifications.
#'   If NULL, sensible defaults (persistent prior on phi, Inv-Gamma on sigma2).
#' @param prior   prior on A: "HS" (default) or "Minnesota".
#' @param shrink.load "rowwise" (default) or "global".
#' @param ident   "identity" (default), "lower.tri", or "unident" for ex-post.
#' @param column.shrink multiplicative gamma-process column shrinkage on
#'   Lambda_mu (default TRUE).
#' @param VAR,FM toggles for the VAR / BART blocks.
#' @param verbose print iteration progress.
#'
#' @return A list with components
#'   \item{pred}{nout x M x nhor draws from the predictive density}
#'   \item{H.store}{nout x T x M log-variances (in-sample)}
#'   \item{sv.par}{nout x M x 3 (mu, phi, sigma) AR(1) SV parameters per series}
#'   \item{A.store, Lambdamu, Lambdaq, mu, q, var.expl}{same shapes as \code{bartfm}}
#'
#' @seealso \code{\link{bartfm}}, \code{stochvol::svsample_fast_cpp}
#' @export
bartfm_sv <- function(Yraw, nsave, nburn, nout,
                      prior = "HS", p = 1,
                      Q.mu = 3, Q.q = 0,
                      sign = FALSE, sign.mat = NULL,
                      nhor = 20,
                      Y.sd = NULL, Y.m = NULL,
                      VAR = TRUE, FM = TRUE,
                      SV.h = TRUE, SV.q = FALSE,
                      sv_priors_h = NULL, sv_priors_q = NULL,
                      shrink.load = "rowwise", ident = "identity",
                      column.shrink = TRUE, a_own = 0.05,
                      X_oos = NULL,
                      X_init_paths = NULL, nhor_paths = 12,
                      keepTrees = FALSE,
                      verbose = FALSE) {

  require(dbarts)
  require(stochvol)

  if (is.null(sign.mat)) sign <- FALSE
  if (sign) {
    signs <- sign.mat
    Q.q   <- ncol(signs)
  }

  bart.prior <- list("level" = 0.95, "exp" = 2, "mu.sd" = 2, "trees" = 250)

  ntot <- nsave + nburn

  M <- ncol(Yraw)
  if (is.null(Y.sd)) Y.sd <- rep(1, M)
  if (is.null(Y.m))  Y.m  <- rep(0, M)

  Y <- embed(Yraw, p + 1)
  X <- cbind(Y[, (M + 1):ncol(Y)], 1)
  Y <- Y[, 1:M]

  T <- nrow(Y)
  K <- ncol(X)
  k <- K * M

  V.a     <- matrix(1, K, M)
  prior.a <- matrix(0, K, M)
  prior.a[1:M, 1:M] <- diag(M) * a_own  ## own-lag prior mean: ~0 for returns, ~1 (RW) for log-levels

  Sigma_q <- diag(max(Q.q, 1))

  ## -------- VAR prior -----------------------------------------------------
  if (prior == "HS") {
    lambda.var <- rep(0.1, k); nu.var <- rep(0.1, k)
    tau.var <- 0.1; zeta.var <- 0.1
  } else {
    sigma.sd <- matrix(NA, M, 1)
    for (j in 1:M) {
      y.j <- Y[, j]; X.j <- embed(y.j, p + 1)
      Y.j <- X.j[, 1]; X.j <- X.j[, 2:ncol(X.j)]
      lm.j <- lm(Y.j ~ X.j)
      sigma.sd[j, 1] <- sqrt(sum(lm.j$residuals^2) / lm.j$df.residual)
    }
    a_bar_1 <- 0.04; a_bar_2 <- 0.0016; a_bar_3 <- 10
    ind <- matrix(0, M, p)
    for (i in 1:M) ind[i, ] <- seq(i, M * p, by = M)
    V.a <- get_V(a_bar_1 = a_bar_1, a_bar_2 = a_bar_2, a_bar_3 = a_bar_3,
                 ind1 = ind, sigma_sq1 = sigma.sd^2, p1 = p, M1 = M, K1 = K)
  }

  ## -------- Lambda.mu prior ------------------------------------------------
  pi.Lambda <- rep(1, max(Q.mu, 1))
  if (column.shrink && Q.mu > 0) {
    kappa <- 2; a_pi <- 3; b_pi <- 0.03
    pi <- 1
    pi.Lambda <- pi / (1:Q.mu)^kappa
  }
  if (shrink.load == "rowwise") {
    lambda.Lambda <- matrix(0.1, max(Q.mu, 1), M)
    nu.Lambda     <- matrix(0.1, max(Q.mu, 1), M)
    tau.Lambda    <- matrix(0.1, M)
    zeta.Lambda   <- matrix(0.1, M)
  } else {
    lambda.Lambda <- rep(0.1, M * max(Q.mu, 1))
    nu.Lambda     <- rep(0.1, M * max(Q.mu, 1))
    tau.Lambda <- 0.1; zeta.Lambda <- 0.1
  }
  if (FM && Q.mu > 0) {
    psi.Lambda <- matrix(1, M, Q.mu)
  } else {
    psi.Lambda <- matrix(1e-14, M, max(Q.mu, 1))
  }
  psi.Lambda.tilde <- psi.Lambda

  ## -------- SV setup -------------------------------------------------------
  ## H stores the log-variance h_{i,t}. Variance at time t for series i is
  ## exp(H[t, i]).  When SV.h=FALSE we still keep the same storage layout but
  ## update h via inverse-gamma on a constant (collapses to homoskedasticity).
  if (is.null(sv_priors_h)) {
    sv_priors_h <- specify_priors(
      mu     = sv_normal(mean = -10, sd = 1.5),   # log-var of daily returns ~ log(1e-4)
      phi    = sv_beta(shape1 = 25, shape2 = 1.5),
      sigma2 = sv_gamma(shape = 0.5, rate = 0.5),
      nu     = sv_infinity(),
      rho    = sv_constant(0))
  }
  if (is.null(sv_priors_q)) sv_priors_q <- sv_priors_h

  sv.h <- vector("list", M)
  for (j in 1:M) {
    sv.h[[j]] <- list(mu = -10, phi = 0.95, sigma = 0.1,
                      nu = Inf, rho = 0, beta = NA, latent0 = -10)
  }
  H       <- matrix(-10, T, M)        ## log-variance, well-scaled for daily returns
  parm.h  <- matrix(0, M, 3); colnames(parm.h) <- c("mu", "phi", "sigma")

  if (Q.q > 0) {
    sv.q <- vector("list", Q.q)
    for (j in 1:Q.q) sv.q[[j]] <- list(mu = 0, phi = 0.95, sigma = 0.1,
                                       nu = Inf, rho = 0, beta = NA, latent0 = 0)
    H.q     <- matrix(0, T, Q.q)
    parm.q  <- matrix(0, Q.q, 3); colnames(parm.q) <- c("mu", "phi", "sigma")
  }

  ## -------- Starting values ------------------------------------------------
  if (VAR) {
    A.draw <- solve(crossprod(X) + 1e-6 * diag(K)) %*% crossprod(X, Y)
  } else {
    A.draw <- matrix(0, K, M)
  }
  Y.A <- Y - X %*% A.draw

  if (Q.mu > 0) {
    pca.f  <- princomp(Y.A)
    f.draw <- pca.f$scores[, 1:Q.mu, drop = FALSE]
    mu <- matrix(0, T, Q.mu)
  } else {
    mu <- matrix(0, T, 1)  ## unused placeholder
  }

  ## -------- BART samplers --------------------------------------------------
  control.bart <- dbartsControl(
    verbose = FALSE, keepTrainingFits = TRUE, useQuantiles = FALSE,
    keepTrees = isTRUE(keepTrees), n.samples = ntot, n.cuts = 100L, n.burn = nburn,
    n.trees = bart.prior$trees, n.chains = 1, n.threads = 1, n.thin = 1L,
    printEvery = 1, printCutoffs = 0L, rngKind = "default",
    rngNormalKind = "default", updateState = FALSE)
  prior.sig  <- c(10000^50, 0.5)
  sigma.init <- 1

  sampler.mu <- list()
  if (FM && Q.mu > 0) {
    for (j in 1:Q.mu) {
      sampler.mu[[j]] <- dbarts(f.draw[, j] ~ cbind(X, 1:T),
        control = control.bart,
        tree.prior = cgm(bart.prior$exp, bart.prior$level),
        node.prior = normal(bart.prior$mu.sd),
        n.samples = nsave, weights = rep(1, T), sigma = sigma.init,
        resid.prior = chisq(prior.sig[[1]], prior.sig[[2]]))
      init.mu.draw <- sampler.mu[[j]]$run(0L, 1L)
      mu[, j] <- init.mu.draw$train
    }
  }
  if (!FM) mu <- mu * 0

  Lambda.mu <- matrix(0, M, max(Q.mu, 1))
  if (FM && Q.mu > 0) {
    for (j in 1:M) {
      Lambda.mu[j, ] <- solve(crossprod(mu) + diag(Q.mu)) %*% crossprod(mu, Y.A[, j])
    }
  }

  if (Q.q > 0) {
    Y.A.mu <- Y - X %*% A.draw - mu %*% t(Lambda.mu)
    pca.q  <- princomp(Y.A.mu)
    q.draw <- pca.q$scores[, 1:Q.q, drop = FALSE]
    Lambda.q <- matrix(0, M, Q.q)
    for (j in 1:M) {
      Lambda.q[j, ] <- solve(crossprod(q.draw) + diag(Q.q)) %*% crossprod(q.draw, Y.A.mu[, j])
    }
  } else {
    q.draw   <- matrix(0, T, 1)
    Lambda.q <- matrix(0, M, 1)
  }

  ## -------- Storage --------------------------------------------------------
  ## If X_oos is provided, OOS predictions are computed at realised X_t (1-step
  ## ahead, conditional on actual data). nhor is then taken from nrow(X_oos)
  ## and the forecasts are no longer self-iterating simulated paths.
  use_X_oos <- !is.null(X_oos)
  if (use_X_oos) {
    X_oos <- as.matrix(X_oos)
    if (ncol(X_oos) != K)
      stop("X_oos has ", ncol(X_oos), " columns; expected K = ", K)
    nhor <- nrow(X_oos)
  }

  A.store        <- array(NA, c(nout, K, M))
  Lambdamu.store <- array(NA, c(nout, M, max(Q.mu, 1)))
  Lambdaq.store  <- array(NA, c(nout, M, max(Q.q, 1)))
  mu.store       <- array(NA, c(nout, T, max(Q.mu, 1)))
  q.store        <- array(NA, c(nout, T, max(Q.q, 1)))
  H.store        <- array(NA, c(nout, T, M))
  sv.par.store   <- array(NA, c(nout, M, 3),
                          dimnames = list(NULL, colnames(Yraw),
                                          c("mu", "phi", "sigma")))
  pred.store     <- array(NA, c(nout, M, nhor),
                          dimnames = list(NULL, colnames(Yraw), 1:nhor))
  pred.h.store   <- array(NA, c(nout, M, nhor))   ## forward log-vars
  var.explained  <- array(NA, c(nout, M))

  ## Multi-step forecast paths from arbitrary starting points: for each row
  ## of X_init_paths, forward-iterate nhor_paths steps using the CURRENT
  ## iter's tree state, parameters and SV state. Storage shape
  ## (nout, M, D, nhor_paths). Each draw gets one stochastic path per init.
  use_paths <- !is.null(X_init_paths)
  if (use_paths) {
    X_init_paths <- as.matrix(X_init_paths)
    if (ncol(X_init_paths) != K)
      stop("X_init_paths has ", ncol(X_init_paths), " cols; expected K = ", K)
    D <- nrow(X_init_paths)
    pred.paths.store <- array(NA, c(nout, M, D, nhor_paths),
                              dimnames = list(NULL, colnames(Yraw), 1:D, 1:nhor_paths))
  }

  thin.set <- round(seq(nburn + 1, ntot, length.out = nout))
  i.count  <- 0

  for (irep in 1:ntot) {

    ## ---- Step I: VAR coefficients --------------------------------------
    Y.q.mu <- Y - mu %*% t(Lambda.mu) - q.draw %*% t(Lambda.q)
    if (VAR) {
      H.var <- exp(H)  ## variance scale for weighting
      for (i in 1:M) {
        w.i <- 1 / sqrt(H.var[, i])
        y.i <- Y.q.mu[, i] * w.i
        X.i <- X * w.i
        V.i <- solve(crossprod(X.i) + diag(1 / V.a[, i]))
        m.i <- V.i %*% (crossprod(X.i, y.i) + diag(1 / V.a[, i]) %*% prior.a[, i])
        A.draw[, i] <- m.i + t(chol(V.i)) %*% rnorm(K)
      }
    }

    ## ---- Step II: Lambda.mu --------------------------------------------
    if (FM && Q.mu > 0) {
      Y.A.q <- Y - X %*% A.draw - q.draw %*% t(Lambda.q)
      H.var <- exp(H)

      if (ident == "identity") {
        i.ident <- Q.mu + 1
        Lambda.mu[1:Q.mu, 1:Q.mu] <- diag(Q.mu)
      } else if (ident == "lower.tri") {
        Lambda.mu[upper.tri(Lambda.mu)] <- 0
        diag(Lambda.mu[1:Q.mu, 1:Q.mu]) <- 1
        i.ident <- 2
      } else {
        i.ident <- 1
      }

      for (i in i.ident:M) {
        if (ident == "lower.tri") {
          if (i == 1) next
          if (i <= Q.mu) {
            y.i <- (Y.A.q[, i] - mu[, i]) / sqrt(H.var[, i])
            X.i <- mu[, 1:(i - 1), drop = FALSE] / sqrt(H.var[, i])
            Q.mu.i <- ncol(X.i)
            prior.lambda.inverse <- if (Q.mu.i > 1) diag(1 / psi.Lambda[i, 1:(i - 1)]) else 1 / psi.Lambda[i, 1:(i - 1)]
            i.cols <- 1:(i - 1)
          } else {
            y.i <- Y.A.q[, i] / sqrt(H.var[, i])
            X.i <- mu / sqrt(H.var[, i])
            Q.mu.i <- ncol(X.i)
            prior.lambda.inverse <- if (Q.mu.i > 1) diag(1 / psi.Lambda[i, ]) else 1 / psi.Lambda[i, ]
            i.cols <- 1:Q.mu
          }
        } else {
          y.i <- Y.A.q[, i] / sqrt(H.var[, i])
          X.i <- mu / sqrt(H.var[, i])
          Q.mu.i <- Q.mu
          prior.lambda.inverse <- if (Q.mu.i > 1) diag(1 / psi.Lambda.tilde[i, ]) else 1 / psi.Lambda.tilde[i, ]
          i.cols <- 1:Q.mu
        }

        V.i <- try(solve(crossprod(X.i) + prior.lambda.inverse), silent = TRUE)
        if (inherits(V.i, "try-error"))
          V.i <- MASS::ginv(crossprod(X.i) + prior.lambda.inverse)

        m.i    <- V.i %*% crossprod(X.i, y.i)
        cholV  <- try(t(chol(V.i)), silent = TRUE)
        if (inherits(cholV, "try-error")) cholV <- t(chol(V.i, pivot = TRUE))

        Lambda.mu[i, i.cols] <- as.numeric(m.i + cholV %*% rnorm(Q.mu.i))
      }
    }

    ## ---- Step III: BART (mu) -------------------------------------------
    if (FM && Q.mu > 0) {
      H.var <- exp(H)
      for (j in 1:Q.mu) {
        ## Guard: if column j of Lambda has collapsed under HS shrinkage
        ## (especially possible with ident != "identity"), the inverse-
        ## scaling normaliser blows up and weights become NaN. Skip BART
        ## update for that column this iter; it will be revisited next iter.
        lam_norm2 <- sum(Lambda.mu[, j]^2)
        if (!is.finite(lam_norm2) || lam_norm2 < 1e-6) next

        resp.j.unscaled <- Y.A.q - mu[, -j, drop = FALSE] %*% t(Lambda.mu[, -j, drop = FALSE])
        lambda.j.scale  <- (1 / lam_norm2) %*% t(Lambda.mu[, j])
        resp.j.scaled   <- resp.j.unscaled %*% t(lambda.j.scale)

        ## Time-varying weights: w_t = 1 / sum_i H.var[t, i] * lambda.j.scale[i]^2
        w_denom <- as.vector(H.var %*% t(lambda.j.scale^2))
        w_denom[!is.finite(w_denom) | w_denom < 1e-8] <- 1e-8
        w.vec <- 1 / w_denom
        sampler.mu[[j]]$setWeights(w.vec)
        sampler.mu[[j]]$setResponse(resp.j.scaled)
        init.mu.draw <- sampler.mu[[j]]$run(0L, 1L)
        mu[, j] <- init.mu.draw$train
      }
    }

    ## ---- Step IV: Lambda.q ---------------------------------------------
    if (Q.q > 0) {
      Y.A.mu <- Y - X %*% A.draw - mu %*% t(Lambda.mu)
      prior.lambda <- if (Q.q > 1) diag(Q.q) / 100 else 1 / 100
      H.var <- exp(H)
      for (mm in 1:M) {
        normalizer <- 1 / sqrt(H.var[, mm])
        q.hat <- q.draw * normalizer
        y.hat <- Y.A.mu[, mm] * normalizer
        L.post <- solve(crossprod(q.hat) + prior.lambda)
        a.post <- L.post %*% crossprod(q.hat, y.hat)
        if (sign) {
          lq <- try(TruncatedNormal::rtmvnorm(
            n = 1, mu = a.post, sigma = L.post,
            ub = sign.mat[mm, , "ub"], lb = sign.mat[mm, , "lb"]), silent = TRUE)
          if (inherits(lq, "try-error"))
            lq <- TruncatedNormal::rtmvnorm(n = 1, mu = a.post,
              sigma = Matrix::forceSymmetric(L.post),
              ub = sign.mat[mm, , "ub"], lb = sign.mat[mm, , "lb"])
          Lambda.q[mm, ] <- lq
        } else {
          Lambda.q[mm, ] <- a.post + t(chol(L.post)) %*% rnorm(Q.q)
        }
      }

      ## ---- Step V: q_t ------------------------------------------------
      Sigma.q.tt <- if (SV.q) NULL else diag(diag(Sigma_q), Q.q)
      for (t in 1:T) {
        Sq <- if (SV.q) diag(exp(H.q[t, ]), Q.q) else Sigma.q.tt
        Qt <- Lambda.q %*% Sq %*% t(Lambda.q) + diag(exp(H[t, ]))
        Qt.inv <- solve(Qt)
        mu.t <- Sq %*% t(Lambda.q) %*% Qt.inv %*% Y.A.mu[t, ]
        V.t  <- Sq - Sq %*% t(Lambda.q) %*% Qt.inv %*% Lambda.q %*% Sq
        q.draw[t, ] <- mu.t + t(chol((V.t + t(V.t)) / 2)) %*% rnorm(Q.q)
      }

      if (SV.q) {
        for (j in 1:Q.q) {
          svdraw <- svsample_fast_cpp(q.draw[, j],
                                      startpara = sv.q[[j]],
                                      startlatent = H.q[, j],
                                      priorspec = sv_priors_q)
          sv.q[[j]][c("mu", "phi", "sigma")] <- as.list(svdraw$para[, c("mu", "phi", "sigma")])
          H.q[, j] <- as.numeric(svdraw$latent)
          parm.q[j, ] <- unlist(sv.q[[j]][c("mu", "phi", "sigma")])
        }
      }
    }

    ## ---- Step VI: idiosyncratic H via SV --------------------------------
    Y.resid <- Y - X %*% A.draw - mu %*% t(Lambda.mu)
    if (Q.q > 0) Y.resid <- Y.resid - q.draw %*% t(Lambda.q)

    if (SV.h) {
      for (j in 1:M) {
        svdraw <- svsample_fast_cpp(Y.resid[, j],
                                    startpara = sv.h[[j]],
                                    startlatent = H[, j],
                                    priorspec = sv_priors_h)
        sv.h[[j]][c("mu", "phi", "sigma")] <- as.list(svdraw$para[, c("mu", "phi", "sigma")])
        H[, j] <- as.numeric(svdraw$latent)
        parm.h[j, ] <- unlist(sv.h[[j]][c("mu", "phi", "sigma")])
      }
      ## numerical floor: avoid pathological log-var collapse
      H[H < -20] <- -20
    } else {
      a_h <- 0.01; b_h <- 0.01
      for (j in 1:M) {
        h_a <- T / 2 + a_h
        h_b <- sum(Y.resid[, j]^2) / 2 + b_h
        sig2 <- 1 / rgamma(1, h_a, h_b)
        H[, j] <- log(sig2)
        parm.h[j, ] <- c(log(sig2), 0, 0)
      }
    }

    ## ---- Step VII: VAR-prior horseshoe ---------------------------------
    if (prior == "HS") {
      a.draw  <- as.vector(A.draw)
      a.prior <- as.vector(prior.a)
      hs.var <- get.hs(a.draw - a.prior, lambda.var, nu.var, tau.var, zeta.var)
      lambda.var <- hs.var$lambda; nu.var <- hs.var$nu
      tau.var <- hs.var$tau; zeta.var <- hs.var$zeta
      V.a <- matrix(hs.var$psi, K, M)
      V.a[V.a < 1e-6] <- 1e-6
    }

    ## ---- Step VIII: Lambda.mu prior ------------------------------------
    if (FM && Q.mu > 0) {
      if (shrink.load == "rowwise") {
        for (j in i.ident:M) {
          if (ident == "lower.tri") {
            sl.lambdamu <- if (j <= Q.mu) 1:(j - 1) else 1:Q.mu
          } else sl.lambdamu <- 1:Q.mu
          lambdamu.j <- Lambda.mu[j, sl.lambdamu]
          get.psi.j <- get.hs(lambdamu.j / sqrt(pi.Lambda),
            lambda.hs = lambda.Lambda[sl.lambdamu, j],
            nu.hs = nu.Lambda[sl.lambdamu, j],
            tau.hs = tau.Lambda[j],
            zeta.hs = zeta.Lambda[j])
          lambda.Lambda[sl.lambdamu, j] <- get.psi.j$lambda
          tau.Lambda[j]    <- get.psi.j$tau
          nu.Lambda[sl.lambdamu, j] <- get.psi.j$nu
          zeta.Lambda[j]   <- get.psi.j$zeta
          psi.Lambda[j, sl.lambdamu] <- get.psi.j$psi
        }
      } else {
        get.psi <- get.hs(as.vector(Lambda.mu), lambda.hs = lambda.Lambda,
                          nu.hs = nu.Lambda, tau.hs = tau.Lambda, zeta.hs = zeta.Lambda)
        lambda.Lambda <- get.psi$lambda; nu.Lambda <- get.psi$nu
        zeta.Lambda <- get.psi$zeta; tau.Lambda <- get.psi$tau
        psi.Lambda <- matrix(get.psi$psi, M, Q.mu)
      }
      psi.Lambda[psi.Lambda > 1e2] <- 1e2
      psi.Lambda[psi.Lambda < 1e-4] <- 1e-4

      if (column.shrink) {
        upd <- update_pi_power(Lambda = Lambda.mu, psi = psi.Lambda,
                               a_pi = a_pi, b_pi = b_pi)
        pi <- upd$pi
        pi.Lambda <- pi / (1:Q.mu)^kappa
      }
      psi.Lambda.tilde <- t(t(psi.Lambda) * pi.Lambda)
      psi.Lambda.tilde[psi.Lambda.tilde < 1e-5] <- 1e-5
      psi.Lambda.tilde[psi.Lambda.tilde > 1e1]  <- 1e1
    }

    ## ---- Store ---------------------------------------------------------
    if (irep %in% thin.set) {
      i.count <- i.count + 1
      A.store[i.count, , ] <- A.draw
      Lambdamu.store[i.count, , ] <- Lambda.mu
      Lambdaq.store[i.count, , ]  <- Lambda.q
      mu.store[i.count, , ] <- mu
      q.store[i.count, , ]  <- q.draw
      H.store[i.count, , ]  <- H
      sv.par.store[i.count, , ] <- parm.h

      ## Predictive distribution.
      ##   If use_X_oos: at each horizon use the realised X_oos[ihorz, ] —
      ##                 the prediction is 1-step-ahead conditional on actual
      ##                 lag history (proper walk-forward).
      ##   Else:         self-iterate XT from simulated YT (h-step paths).
      YT <- Y[T, ]; hT <- H[T, ]
      if (use_X_oos) {
        XT <- X_oos[1, ]
      } else {
        XT <- X[T, ]
        if (p == 1) XT <- c(YT, 1) else XT <- c(YT, XT[1:(M * (p - 1))], 1)
      }

      hqT <- if (Q.q > 0 && SV.q) H.q[T, ] else NULL

      for (ihorz in 1:nhor) {
        if (use_X_oos) XT <- X_oos[ihorz, ]

        ## Forward-step SV: h_{T+ihorz, j} = mu + phi * (h_prev - mu) + sigma * z
        if (SV.h) {
          hT <- parm.h[, 1] + parm.h[, 2] * (hT - parm.h[, 1]) +
                parm.h[, 3] * rnorm(M)
        }
        pred.h.store[i.count, , ihorz] <- hT

        tree.pred <- if (FM && Q.mu > 0) {
          ## With keepTrees=TRUE, predict() returns one column per stored tree;
          ## we want the MOST RECENT one (the current iter's tree).
          sapply(sampler.mu, function(s) {
            tp <- s$predict(XT)
            if (length(tp) > 1) as.numeric(tp[1, ncol(as.matrix(tp))])
            else as.numeric(tp)
          })
        } else rep(0, max(Q.mu, 1))

        var.pred <- t(A.draw) %*% XT

        ## q innovations
        if (Q.q > 0) {
          if (SV.q) {
            hqT <- parm.q[, 1] + parm.q[, 2] * (hqT - parm.q[, 1]) +
                   parm.q[, 3] * rnorm(Q.q)
            q.shock <- rnorm(Q.q, 0, sqrt(exp(hqT)))
          } else {
            q.shock <- rnorm(Q.q, 0, sqrt(diag(Sigma_q)))
          }
        } else {
          q.shock <- 0
        }

        YT.new <- as.numeric(var.pred + Lambda.mu %*% tree.pred +
                             Lambda.q %*% q.shock + rnorm(M, 0, sqrt(exp(hT))))

        YT.orig <- YT.new * Y.sd + Y.m
        pred.store[i.count, , ihorz] <- YT.orig

        if (!use_X_oos) {
          YT <- YT.new
          if (p == 1) XT <- c(YT, 1) else XT <- c(YT, XT[1:(M * (p - 1))], 1)
        }
      }

      ## Variance share due to nonlinear block (rough proxy)
      if (FM && Q.mu > 0) {
        nominator   <- diag(Lambda.mu %*% diag(apply(mu, 2, var)) %*% t(Lambda.mu)) /
                       apply(Y, 2, var)
        denominator <- nominator + diag(Lambda.q %*% t(Lambda.q)) + exp(H[T, ])
        var.explained[i.count, ] <- (nominator / denominator) * 100
      }

      ## Multi-step forecast paths from each row of X_init_paths.
      if (use_paths) {
        for (d in 1:D) {
          x_d <- X_init_paths[d, ]
          h_d <- H[T, ]
          for (h in 1:nhor_paths) {
            if (SV.h) {
              h_d <- parm.h[, 1] + parm.h[, 2] * (h_d - parm.h[, 1]) +
                     parm.h[, 3] * rnorm(M)
            }
            tree_pred_d <- if (FM && Q.mu > 0) {
              sapply(sampler.mu, function(s) {
                tp <- s$predict(x_d)
                if (length(tp) > 1) as.numeric(tp[1, ncol(as.matrix(tp))])
                else as.numeric(tp)
              })
            } else rep(0, max(Q.mu, 1))
            var_pred_d <- t(A.draw) %*% x_d
            y_std <- as.numeric(var_pred_d + Lambda.mu %*% tree_pred_d +
                                rnorm(M, 0, sqrt(exp(h_d))))
            pred.paths.store[i.count, , d, h] <- y_std * Y.sd + Y.m
            if (p == 1) x_d <- c(y_std, 1)
            else        x_d <- c(y_std, x_d[1:(M * (p - 1))], 1)
          }
        }
      }
    }

    if (verbose && irep %% 50 == 0) cat("iter", irep, "/", ntot, "\n")
  }

  out <- list(pred = pred.store, pred.h = pred.h.store,
       A.store = A.store, mu = mu.store, q = q.store,
       Lambdamu = Lambdamu.store, Lambdaq = Lambdaq.store,
       H.store = H.store, sv.par = sv.par.store,
       var.expl = var.explained,
       X = X, Y = Y, p = p, M = M, K = K, T = T,
       Q.mu = Q.mu, Q.q = Q.q,
       Y.sd = Y.sd, Y.m = Y.m, var.names = colnames(Yraw),
       SV.h = SV.h, SV.q = SV.q,
       used_X_oos = use_X_oos,
       last_H_T = H[T, ],
       last_Y_T = Y[T, ])
  if (use_paths) out$pred_paths <- pred.paths.store
  if (isTRUE(keepTrees)) out$sampler.mu <- sampler.mu
  class(out) <- c("bartfm_sv", "list")
  out
}

## -----------------------------------------------------------------------------
## predict_bartfm_sv: posterior-predictive draws at an arbitrary new X sequence.
## Requires the fit object to carry the BART samplers (i.e. fitted with
## keepTrees = TRUE). At each thinned posterior index i in 1..nout, computes
## y_oos[i, , t] for t = 1..nrow(X_new), using:
##   y = A_i' x_t + Lambda_mu_i %*% tree_pred_i(x_t)
##         + Lambda_q_i %*% rnorm(Q.q, 0, sqrt(diag(Sigma_q_or_SV_q)))
##         + rnorm(M, 0, sqrt(exp(h_{i,t}))),
## with h forward-stepped from fit$last_H_T using fit$sv.par.
##
## n_paths controls Monte-Carlo paths per draw for averaging the q-shock /
## idiosyncratic noise contribution to the predictive mean. Set to 1 for
## raw stochastic draws.
##
##' @export
predict_bartfm_sv <- function(fit, X_new, n_paths = 1) {
  if (is.null(fit$sampler.mu) && fit$Q.mu > 0)
    stop("fit was not built with keepTrees = TRUE; cannot predict OOS.")
  X_new <- as.matrix(X_new)
  if (ncol(X_new) != fit$K)
    stop("X_new has ", ncol(X_new), " columns; expected K = ", fit$K)

  nout  <- dim(fit$A.store)[1]
  M     <- fit$M; K <- fit$K; T_oos <- nrow(X_new)
  Q.mu  <- fit$Q.mu

  ## BART predictions across all stored trees: each sampler returns a
  ## (T_oos x n.samples_kept) matrix. We then thin to nout in the same
  ## stride as the parameter storage (round(seq(...))).
  if (Q.mu > 0) {
    pred_mu_all <- lapply(fit$sampler.mu, function(s) s$predict(X_new))
    n_kept <- ncol(pred_mu_all[[1]])
    thin_idx <- round(seq(1, n_kept, length.out = nout))
    pred_mu  <- array(NA, c(nout, T_oos, Q.mu))
    for (j in seq_len(Q.mu))
      pred_mu[, , j] <- t(pred_mu_all[[j]][, thin_idx, drop = FALSE])
  } else {
    pred_mu <- array(0, c(nout, T_oos, 1))
  }

  out <- array(NA, c(nout, M, T_oos),
               dimnames = list(NULL, fit$var.names, NULL))

  for (i in seq_len(nout)) {
    A_i <- fit$A.store[i, , ]
    L_i <- fit$Lambdamu[i, , , drop = FALSE]; dim(L_i) <- c(M, Q.mu)
    Lq_i <- fit$Lambdaq[i, , , drop = FALSE]; dim(Lq_i) <- c(M, dim(fit$Lambdaq)[3])
    sv_i <- fit$sv.par[i, , ]
    h_prev <- fit$last_H_T

    for (t in 1:T_oos) {
      if (fit$SV.h) {
        h_prev <- sv_i[, 1] + sv_i[, 2] * (h_prev - sv_i[, 1]) +
                  sv_i[, 3] * rnorm(M)
      }
      tree_pred <- if (Q.mu > 0) pred_mu[i, t, ] else rep(0, max(Q.mu, 1))

      ## average over n_paths Monte Carlo shocks (each path: noise + q-factor)
      y_acc <- numeric(M)
      for (pp in 1:n_paths) {
        eps   <- rnorm(M, 0, sqrt(exp(h_prev)))
        q_sh  <- if (fit$Q.q > 0) rnorm(fit$Q.q) else 0
        y_acc <- y_acc + as.numeric(t(A_i) %*% X_new[t, ] +
                                    L_i %*% tree_pred +
                                    Lq_i %*% q_sh + eps)
      }
      y <- y_acc / n_paths
      out[i, , t] <- y * fit$Y.sd + fit$Y.m
    }
  }
  out
}
