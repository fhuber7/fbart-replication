## =====================================================================
## identify_factors.R -- ex-post posterior projection for factorBART.
##
## Implements the projection of Chakraborty, Walsh, Strigari, Mallick &
## Bhattacharya (2026, Technometrics, 68(1), 14-23) for our setting
##
##   y_t = A x_t + Lambda_mu mu(x_t) + Lambda_q q_t + eps_t.
##
## The role of the "computer model" f(x, theta) is played by A x_t and
## the role of the "bias function" b(x) is played by Lambda_mu mu(x_t).
## Their condition (4) for the case of M outputs and K linear inputs
## reduces -- after evaluation on the empirical distribution of X --
## to the matrix orthogonality
##
##                  X' [ mu(X) Lambda_mu' ] = 0_{K x M}.
##
## The Hilbert projection (their Lemma 3.3) then has closed form: for
## each posterior draw indexed by s,
##
##   beta_s     = (X'X)^{-1} X' mu_s              [K x Q_mu]
##   mu_s^perp  = mu_s - X beta_s                 [T x Q_mu]
##   A_s^*      = A_s + beta_s Lambda_s'          [K x M]
##
## The fitted value X A_s + mu_s Lambda_s' is *invariant* under this
## projection -- only the linear vs. nonlinear split is moved.  After
## projection, A_s^* is identified (it is the population BLP coefficient
## conditional on the same nonlinear factor map), and Lambda_mu mu^perp
## is the X-orthogonal nonlinear residual.
##
## Column rotation/sign/scale of (Lambda_mu, mu^perp) are still free
## (linear factor model invariance).  We follow the existing maximin
## sign / column ordering used by the production code (signident()) and
## scale columns of mu^perp to unit s.d. with the scale absorbed into
## Lambda_mu.  Optionally a varimax rotation is applied to maximise
## interpretability of the loadings.
## =====================================================================

#' Ex-post identification of (A, Lambda_mu, mu(X)) by posterior projection
#'
#' Applies the Chakraborty-Walsh-Strigari-Mallick-Bhattacharya (2026,
#' Technometrics) Hilbert projection -- adapted to our factor-augmented
#' BART VAR -- to each posterior draw, then fixes the residual rotation /
#' sign / scale of the nonlinear factor block.
#'
#' Concretely, for each draw \eqn{s} the function
#' \enumerate{
#'   \item projects \eqn{\mu^{(s)}(X)} onto the orthogonal complement of the
#'         column space of \eqn{X}, producing \eqn{\mu^{\perp,(s)}};
#'   \item absorbs the linear component of \eqn{\mu^{(s)}} into \eqn{A^{(s)}}
#'         via \eqn{A^{*,(s)} = A^{(s)} + \beta^{(s)} \Lambda_\mu^{(s)'}};
#'   \item rescales each column of \eqn{\mu^{\perp,(s)}} to unit sample s.d.
#'         and absorbs the scale into \eqn{\Lambda_\mu^{(s)}};
#'   \item (if \code{rotate = TRUE}) applies a varimax rotation to the
#'         posterior-average loading matrix and rotates every draw by the
#'         same orthogonal matrix, fixing the column subspace;
#'   \item runs the maximin sign / column-permutation routine
#'         \code{signident} so that columns are ordered consistently across
#'         draws.
#' }
#' The fitted value \eqn{X A^{(s)} + \mu^{(s)} \Lambda_\mu^{(s)'}} is
#' invariant under steps 1-2; steps 3-5 are additional normalisations that
#' make individual columns and rows comparable across MCMC iterations.
#'
#' @param fit  output of \code{\link{bartfm}} (must contain \code{A.store},
#'   \code{Lambdamu}, \code{mu}, \code{X}).
#' @param rotate logical; apply a varimax rotation that aligns columns
#'   across draws (default \code{TRUE}).
#' @param rescale logical; rescale columns of mu to unit s.d. per draw and
#'   absorb scale into Lambda_mu (default \code{TRUE}).
#' @param signident logical; apply maximin sign/column reordering after
#'   rotation (default \code{TRUE}).
#' @param verbose  print progress.
#'
#' @return A list with the projected/identified posterior draws:
#'   \item{A}{nout x K x M draws of A* (with the linear component of mu
#'            absorbed)}
#'   \item{Lambdamu}{nout x M x Q.mu rotated/rescaled/sign-flipped loadings}
#'   \item{mu}{nout x T x Q.mu X-orthogonal factor draws (unit s.d. per
#'            column)}
#'   \item{ortho.check}{nout vector of \code{max(abs(X' mu))} -- should be
#'            ~1e-12 (machine precision) for all draws}
#'   \item{rot}{Q.mu x Q.mu orthogonal rotation matrix used (identity if
#'            \code{rotate = FALSE})}
#'   \item{call}{original call to bartfm via \code{fit$call} or NULL}
#'
#' @section Note on identification:
#'   The projection alone (steps 1-2) is what makes \eqn{A} identified --
#'   without further assumption the column subspace of \eqn{\mu^\perp} and
#'   the row span of \eqn{\Lambda_\mu} are still only jointly identified up
#'   to a \eqn{Q_\mu \times Q_\mu} rotation.  Steps 3-5 are conventional
#'   linear-factor-model normalisations: unit-scale columns, varimax for
#'   interpretability, and maximin sign/order matching across draws.
#'
#' @references
#' Chakraborty, A., Walsh, J. L., Strigari, L., Mallick, B. K., & Bhattacharya, A.
#' (2026). Orthogonal Calibration via Posterior Projections with Applications to
#' the Schwarzschild Model. \emph{Technometrics}, 68(1), 14-23.
#'
#' @seealso \code{\link{bartfm}}
#' @export
identify_factors <- function(fit,
                             rotate    = TRUE,
                             rescale   = TRUE,
                             signident = TRUE,
                             verbose   = FALSE) {

  ## --- 0. unpack ------------------------------------------------------
  if (!all(c("A.store", "Lambdamu", "mu", "X") %in% names(fit)))
    stop("fit must contain A.store, Lambdamu, mu and X")
  A.in   <- fit$A.store                # nout x K x M
  L.in   <- fit$Lambdamu                # nout x M x Q.mu
  mu.in  <- fit$mu                      # nout x T x Q.mu
  X      <- as.matrix(fit$X)            # T x K
  nout   <- dim(A.in)[1]
  K      <- ncol(X);  T <- nrow(X)
  M      <- dim(L.in)[2];  Q.mu <- dim(L.in)[3]
  stopifnot(dim(A.in)[2] == K, dim(A.in)[3] == M,
            dim(mu.in)[2] == T, dim(mu.in)[3] == Q.mu)

  ## --- 1. one-shot inverse used by every draw -------------------------
  XtX     <- crossprod(X)
  XtX.inv <- tryCatch(solve(XtX),
                      error = function(e) MASS::ginv(XtX))

  ## --- 2. allocate output containers ----------------------------------
  A.out   <- A.in
  L.out   <- L.in
  mu.out  <- mu.in
  leak    <- numeric(nout)

  ## --- 3. PROJECTION + RESCALE per draw -------------------------------
  for (s in seq_len(nout)) {
    A_s   <- A.in[s, , ]                # K x M
    L_s   <- L.in[s, , ]                # M x Q.mu
    mu_s  <- mu.in[s, , ]               # T x Q.mu

    ## (i) Hilbert projection: mu -> mu - X (X'X)^-1 X' mu
    beta_s   <- XtX.inv %*% crossprod(X, mu_s)        # K x Q.mu
    mu_perp  <- mu_s - X %*% beta_s                   # T x Q.mu
    ## (ii) absorb the linear component of mu into A
    A_star   <- A_s + beta_s %*% t(L_s)               # K x M

    ## (iii) per-column scale normalisation: sd(mu_k) = 1
    if (rescale) {
      sds          <- pmax(apply(mu_perp, 2, sd), 1e-12)
      mu_perp      <- sweep(mu_perp, 2, sds, FUN = "/")
      L_s          <- sweep(L_s, 2, sds, FUN = "*")
    }

    A.out [s, , ] <- A_star
    L.out [s, , ] <- L_s
    mu.out[s, , ] <- mu_perp
    leak[s]       <- max(abs(crossprod(X, mu_perp)))

    if (verbose && (s %% 100 == 0))
      message(sprintf("[identify_factors] %d / %d  | leak %.2e",
                      s, nout, leak[s]))
  }

  ## --- 4. (optional) one-time rotation that aligns the column space
  ##       of Lambda_mu across draws (varimax on the posterior mean).
  ##       Apply the SAME orthogonal rotation R to every draw so that the
  ##       fitted value Lambda_mu mu' is unchanged.
  rot <- diag(Q.mu)
  if (rotate && Q.mu > 1) {
    L.bar  <- apply(L.out, c(2, 3), mean)             # M x Q.mu
    vm     <- stats::varimax(L.bar, normalize = FALSE)
    rot    <- vm$rotmat                               # Q.mu x Q.mu (orthogonal)
    for (s in seq_len(nout)) {
      L.out [s, , ] <-  L.out [s, , ]      %*% rot
      mu.out[s, , ] <-  mu.out[s, , ]      %*% rot
    }
  }

  ## --- 5. maximin sign / column reorder -- same routine as the
  ##       production code so columns line up across draws.
  if (signident && Q.mu > 1) {
    ## signident() expects facload as M x Q.mu x nout, fac as Q.mu x T x nout
    fl <- aperm(L.out,  c(2, 3, 1))
    ff <- aperm(mu.out, c(3, 2, 1))
    si <- signident(list(facload = fl, fac = ff),
                    method = "maximin", implementation = 3)
    L.out  <- aperm(si$facload, c(3, 1, 2))
    mu.out <- aperm(si$fac,     c(3, 2, 1))
  }

  list(
    A         = A.out,
    Lambdamu  = L.out,
    mu        = mu.out,
    ortho.check = leak,
    rot       = rot,
    call      = match.call()
  )
}
